import 'dart:io' show File;
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/job.dart';
import '../models/job_note.dart';
import '../services/note_service.dart';
import '../services/session_login.dart';

class JobNotesScreen extends StatefulWidget {
  final Job job;
  const JobNotesScreen({super.key, required this.job});

  @override
  State<JobNotesScreen> createState() => _JobNotesScreenState();
}

class _JobNotesScreenState extends State<JobNotesScreen> {
  final _service = NoteService();
  final TextEditingController _noteCtl = TextEditingController();
  final ImagePicker _picker = ImagePicker();

  // Mobile preview
  File? _photoFile;
  // Web preview
  Uint8List? _photoBytes;
  String? _photoName;

  late Future<List<JobNote>> _notesFuture;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _notesFuture = _service.fetchNotesRaw(widget.job.jobId).then(
          (rows) => rows.map(JobNote.fromJson).toList(),
    );
  }

  Future<void> _pickFromGallery() async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
      );
      if (picked == null) return;

      if (kIsWeb) {
        final bytes = await picked.readAsBytes();
        setState(() {
          _photoBytes = bytes;
          _photoName = picked.name;
          _photoFile = null;
        });
      } else {
        setState(() {
          _photoFile = File(picked.path);
          _photoBytes = null;
          _photoName = picked.name;
        });
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gallery error: $e')),
      );
    }
  }

  Future<void> _takePhoto() async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 85,
      );
      if (picked == null) return;

      if (kIsWeb) {
        final bytes = await picked.readAsBytes();
        setState(() {
          _photoBytes = bytes;
          _photoName = picked.name;
          _photoFile = null;
        });
      } else {
        setState(() {
          _photoFile = File(picked.path);
          _photoBytes = null;
          _photoName = picked.name;
        });
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Camera error: $e')),
      );
    }
  }

  Future<void> _save() async {
    try {
      final mechanicId = (await SessionLogin.getMechanicId())?.trim();
      if (mechanicId == null || mechanicId.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No session')),
        );
        return;
      }

      String? url;
      if (kIsWeb && _photoBytes != null && _photoName != null) {
        url = await _service.uploadPhotoBytes(
          _photoBytes!,
          jobId: widget.job.jobId,
          originalFileName: _photoName!,
        );
      } else if (!kIsWeb && _photoFile != null) {
        url = await _service.uploadPhoto(
          _photoFile!,
          jobId: widget.job.jobId,
        );
      }

      await _service.addNote(
        jobId: widget.job.jobId,
        mechanicId: mechanicId,
        noteText: _noteCtl.text.trim().isEmpty ? null : _noteCtl.text.trim(),
        photoUrl: url,
      );

      _noteCtl.clear();
      setState(() {
        _photoFile = null;
        _photoBytes = null;
        _photoName = null;
        _reload();
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Note saved')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Save failed: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasPreview = kIsWeb ? _photoBytes != null : _photoFile != null;
    final bool isCompleted = widget.job.status == 'Completed';

    return Scaffold(
      appBar: AppBar(title: Text('Notes • ${widget.job.jobId}')),
      body: Column(
        children: [
          if (isCompleted)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: MaterialBanner(
                content: const Text('Job is Completed — notes & photos are read-only.'),
                leading: const Icon(Icons.lock, color: Colors.amber),
                actions: const [SizedBox.shrink()],
                backgroundColor: Colors.black54,
              ),
            ),

            Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                TextField(
                  controller: _noteCtl,
                  readOnly: isCompleted,
                  decoration: const InputDecoration(
                    labelText: 'Enter note',
                    filled: true,
                    fillColor: Colors.white10,
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (!isCompleted) ...[
                      ElevatedButton.icon(
                        onPressed: _takePhoto,
                        icon: const Icon(Icons.photo_camera),
                        label: const Text('Take Photo'),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: _pickFromGallery,
                        icon: const Icon(Icons.photo_library),
                        label: const Text('Gallery'),
                      ),
                      const Spacer(),
                      ElevatedButton(
                        onPressed: _save,
                        child: const Text('Save'),
                      ),
                    ] else
                      const SizedBox.shrink(),
                  ],
                ),
                if (!isCompleted && hasPreview) ...[
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: kIsWeb
                        ? Image.memory(_photoBytes!, height: 140, fit: BoxFit.cover)
                        : Image.file(_photoFile!, height: 140, fit: BoxFit.cover),
                  ),
                ],
              ],
            ),
            ),
          const Divider(height: 1),

          Expanded(
            child: FutureBuilder<List<JobNote>>(
              future: _notesFuture,
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snap.hasError) {
                  return Center(child: Text('Error: ${snap.error}'));
                }
                final notes = snap.data ?? [];
                if (notes.isEmpty) return const Center(child: Text('No notes yet.'));

                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemBuilder: (_, i) {
                    final n = notes[i];
                    return ListTile(
                      leading: n.photoUrl != null
                          ? CircleAvatar(backgroundImage: NetworkImage(n.photoUrl!))
                          : const CircleAvatar(child: Icon(Icons.note)),
                      title: Text(n.noteText ?? '(photo only)'),
                      subtitle: Text(n.createdAt.toLocal().toString()),
                      onTap: n.photoUrl != null
                          ? () => showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          child: InteractiveViewer(
                            child: Image.network(n.photoUrl!, fit: BoxFit.contain),
                          ),
                        ),
                      )
                          : null,
                    );
                  },
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemCount: notes.length,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
