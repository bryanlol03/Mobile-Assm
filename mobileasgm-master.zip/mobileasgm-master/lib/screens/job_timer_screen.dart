import 'package:flutter/material.dart';
import '../models/job.dart';
import 'job_notes_screen.dart';

class JobTimerScreen extends StatefulWidget {
  final Job job;
  const JobTimerScreen({super.key, required this.job});

  @override
  State<JobTimerScreen> createState() => _JobTimerScreenState();
}

class _JobTimerScreenState extends State<JobTimerScreen> {
  Stopwatch stopwatch = Stopwatch();
  String elapsed = "0s";

  void _start() {
    stopwatch.start();
    _tick();
  }

  void _tick() async {
    while (stopwatch.isRunning) {
      await Future.delayed(const Duration(seconds: 1));
      setState(() {
        elapsed =
        "${stopwatch.elapsed.inMinutes}m ${stopwatch.elapsed.inSeconds % 60}s";
      });
    }
  }

  void _stopAndContinue() async {
    stopwatch.stop();

    final updated = await Navigator.push<Job>(
      context,
      MaterialPageRoute(builder: (_) => JobNotesScreen(job: widget.job)),
    );

    if (updated != null) {
      Navigator.pop(context, updated);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Job Timer")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Elapsed: $elapsed", style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _start, child: const Text("Start")),
            ElevatedButton(
                onPressed: _stopAndContinue,
                child: const Text("Stop & Continue")),
          ],
        ),
      ),
    );
  }
}
