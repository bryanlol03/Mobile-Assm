import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/session_login.dart';
import 'login_screen.dart';
import '../widgets/bottom_nav_bar.dart';


// NEW widgets
import '../widgets/profile_header.dart';
import '../widgets/info_tile.dart';
import '../widgets/section_title.dart';
import '../widgets/string_list_cards.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _client = Supabase.instance.client;
  Map<String, dynamic>? mechanicData;

  String mechanicId = '';
  String mechanicName = '';
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final id = await SessionLogin.getMechanicId();
    final name = await SessionLogin.getMechanicName();

    if (id == null || name == null) {
      _logout();
      return;
    }

    final response = await _client
        .from('mechanics')
        .select()
        .eq('mechanics_id', id)
        .maybeSingle();

    setState(() {
      mechanicId = id;
      mechanicName = name;
      mechanicData = response;
      isLoading = false;
    });
  }

  void _logout() async {
    await SessionLogin.clearSession();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final data = mechanicData ?? {};

    final skills = (data['skills'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];
    final certs  = (data['certifications'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];

    return Scaffold(
      appBar: AppBar(
        title: const Text("My Profile"),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _logout,
            tooltip: "Logout",
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavBar(currentIndex: 2),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : mechanicData == null
          ? const Center(child: Text("Profile not found"))
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ProfileHeader(
              name: data['name'] ?? '',
              role: data['role'] ?? '',
            ),
            const SizedBox(height: 20),
            InfoTile(
              icon: Icons.email,
              iconColor: Colors.blue,
              text: data['email'] ?? '',
            ),
            const SizedBox(height: 8),
            InfoTile(
              icon: Icons.phone,
              iconColor: Colors.green,
              text: data['phone'] ?? '',
            ),
            const SizedBox(height: 20),
            const SectionTitle("Skills"),
            const SizedBox(height: 10),
            StringListCards(
              items: skills,
              icon: Icons.build,
              iconColor: Colors.orange,
            ),
            const SizedBox(height: 20),
            const SectionTitle("Certifications"),
            const SizedBox(height: 10),
            StringListCards(
              items: certs,
              icon: Icons.verified,
              iconColor: Colors.purple,
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: _logout,
              icon: const Icon(Icons.logout),
              label: const Text("Logout"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
                textStyle: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
