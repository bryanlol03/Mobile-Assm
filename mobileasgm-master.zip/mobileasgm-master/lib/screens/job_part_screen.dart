// screens/job_part_screen.dart
import 'package:flutter/material.dart';
import '../models/part.dart';
import '../models/selected_part.dart';
import '../services/job_service.dart';

class JobPartScreen extends StatefulWidget {
  final String jobId;
  const JobPartScreen({ Key? key, required this.jobId }) : super(key: key);

  @override
  State<JobPartScreen> createState() => _JobPartScreenState();
}

class _JobPartScreenState extends State<JobPartScreen> {
  final JobService _jobService = JobService();
  late Future<List<Part>> _partsFuture;

  final Map<String, SelectedPart> _selected = {};
  final _searchCtl = TextEditingController();
  String _query = '';

  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _partsFuture = _jobService.fetchAvailableParts();
    _searchCtl.addListener(() {
      final q = _searchCtl.text.trim();
      if (q != _query) setState(() => _query = q);
    });
  }

  @override
  void dispose() {
    _searchCtl.dispose();
    super.dispose();
  }

  num get _totalCost =>
      _selected.values.fold<num>(0, (sum, sp) => sum + sp.lineTotal);

  void _increment(Part part) {
    setState(() {
      final sel = _selected[part.partId];
      if (sel == null) {
        if (part.stockQuantity > 0) {
          _selected[part.partId] = SelectedPart(part: part, quantity: 1);
        }
      } else {
        if (sel.quantity < part.stockQuantity) {
          sel.quantity += 1;
        }
      }
    });
  }

  void _decrement(Part part) {
    setState(() {
      final sel = _selected[part.partId];
      if (sel != null) {
        sel.quantity -= 1;
        if (sel.quantity <= 0) {
          _selected.remove(part.partId);
        }
      }
    });
  }

  Future<void> _submit() async {
    if (_selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select some parts.')),
      );
      return;
    }
    setState(() => _isSubmitting = true);
    try {
      await _jobService.addJobParts(
        jobId: widget.jobId,
        selectedParts: _selected.values.toList(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Parts added successfully')),
      );
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  List<Part> _filterParts(List<Part> parts) {
    if (_query.isEmpty) return parts;
    final q = _query.toLowerCase();
    return parts.where((p) {
      return p.name.toLowerCase().contains(q) || p.partId.toLowerCase().contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Parts to Job'),
      ),
      body: FutureBuilder<List<Part>>(
        future: _partsFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }

          final allParts = snap.data ?? [];
          if (allParts.isEmpty) {
            return const Center(child: Text('No parts available.'));
          }
          final parts = _filterParts(allParts);

          return Column(
            children: [
              // --- Search bar ---
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                child: TextField(
                  controller: _searchCtl,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.search),
                    hintText: 'Search parts by name or ID…',
                    filled: true,
                    fillColor: Theme.of(context).colorScheme.surfaceVariant.withOpacity(.25),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    suffixIcon: _query.isEmpty
                        ? null
                        : IconButton(
                      tooltip: 'Clear',
                      icon: const Icon(Icons.clear),
                      onPressed: () => _searchCtl.clear(),
                    ),
                  ),
                  textInputAction: TextInputAction.search,
                ),
              ),

              // Optional small info row
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Row(
                  children: [
                    Text(
                      'Showing ${parts.length} of ${allParts.length} parts',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),

              Expanded(
                child: ListView.builder(
                  itemCount: parts.length,
                  itemBuilder: (context, idx) {
                    final part = parts[idx];
                    final sel = _selected[part.partId];
                    final qty = sel?.quantity ?? 0;
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                      child: ListTile(
                        title: Text('${part.name}  •  ${part.partId}',
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Price: ${part.unitPrice.toStringAsFixed(2)}'),
                            Text('In Stock: ${part.stockQuantity}'),
                            if (qty > 0)
                              Text('Selected: $qty • Total: ${(part.unitPrice * qty).toStringAsFixed(2)}'),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove_circle_outline),
                              onPressed: qty > 0 ? () => _decrement(part) : null,
                            ),
                            Text(qty.toString(), style: const TextStyle(fontSize: 16)),
                            IconButton(
                              icon: const Icon(Icons.add_circle_outline),
                              onPressed: qty < part.stockQuantity ? () => _increment(part) : null,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              Container(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total Cost:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        Text(_totalCost.toStringAsFixed(2),
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isSubmitting ? null : _submit,
                        child: _isSubmitting
                            ? const SizedBox(
                          height: 20, width: 20,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                        )
                            : const Text('Submit Parts'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
