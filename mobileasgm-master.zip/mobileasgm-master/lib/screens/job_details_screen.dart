import 'package:flutter/material.dart';
import '../models/job.dart';
import '../models/job_details.dart';
import '../services/job_service.dart';
import 'job_part_screen.dart';
import 'job_completion_screen.dart';

// widgets
import '../widgets/section_card.dart';
import '../widgets/info_row.dart';
import '../widgets/quick_actions.dart';
import '../widgets/parts_list.dart';

const kAllowedStatuses = <String>[
  'Pending',
  'In Progress',
  'On Hold',
  'Completed',
];

const Map<String, List<String>> kTransitions = {
  'Pending': ['In Progress'],
  'In Progress': ['On Hold'],
  'On Hold': ['Completed'],
  'Completed': [],
};

class JobDetailsScreen extends StatefulWidget {
  final Job job;
  const JobDetailsScreen({super.key, required this.job});

  @override
  State<JobDetailsScreen> createState() => _JobDetailsScreenState();
}

class _JobDetailsScreenState extends State<JobDetailsScreen> {
  final _service = JobService();
  late Future<JobDetails?> _detailsFuture;

  late String _status;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _status = widget.job.status;
    _detailsFuture = _service.getJobDetailsById(widget.job.jobId);
  }

  Future<void> _refresh() async {
    setState(() {
      _detailsFuture = _service.getJobDetailsById(widget.job.jobId);
    });
  }

  Future<void> _saveStatus() async {
    if (_saving) return;

    final original = widget.job.status;
    final allowedNext = kTransitions[original] ?? [];
    final nextStep = allowedNext.isNotEmpty ? allowedNext.first : null;

    // must be exactly the next step
    if (_status != nextStep) return;

    setState(() => _saving = true);
    try {
      if (_status == 'Completed') {
        // fetch latest to pass customerId to sign screen
        final details = await _service.getJobDetailsById(widget.job.jobId);

        // push signature screen and expect a bool
        final signed = await Navigator.push<bool>(
          context,
          MaterialPageRoute(
            builder: (_) => JobCompletionScreen(
              job: widget.job,
              customerId: details?.customerId, // can be null — your save supports it
            ),
          ),
        );

        if (signed != true) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Signature required to complete the job')),
            );
          }
          return;
        }

        // signature done → now mark complete
        await _service.updateJobStatus(jobId: widget.job.jobId, newStatus: 'Completed');

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Job marked as Completed ✅')),
        );
        Navigator.pop(context, widget.job.copyWith(status: 'Completed'));
      } else {
        // regular forward step
        await _service.updateJobStatus(jobId: widget.job.jobId, newStatus: _status);

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Status updated')),
        );
        Navigator.pop(context, widget.job.copyWith(status: _status));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Update failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }


  @override
  Widget build(BuildContext context) {
    final original = widget.job.status;                 // server/original status
    final allowedNext = kTransitions[original] ?? [];
    final nextStep = allowedNext.isNotEmpty ? allowedNext.first : null;

    final shownOptions = <String>{
      original,
      if (nextStep != null) nextStep,
    }.toList();

    final isCompleted = original == 'Completed';
    final canSave = !isCompleted && _status != original && _status == nextStep;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Job Details"),
        actions: [
          DropdownButton<String>(
            value: _status,
            items: shownOptions
                .map((s) => DropdownMenuItem(
              value: s,
              child: Row(
                children: [
                  Text(s),
                  if (s == original)
                    const Padding(
                      padding: EdgeInsets.only(left: 8),
                      child: Text('(current)', style: TextStyle(fontSize: 12, color: Colors.white54)),
                    ),
                ],
              ),
            ))
                .toList(),
            onChanged: isCompleted ? null : (v) => setState(() => _status = v ?? _status),
          ),
          TextButton.icon(
            onPressed: (canSave && !_saving) ? _saveStatus : null,
            icon: _saving
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save, size: 18, color: Colors.white),
            label: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<JobDetails?>(
          future: _detailsFuture,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return Center(child: Text("Error: ${snap.error}"));
            }

            final details = snap.data;
            if (details == null) {
              return const Center(child: Text("Job details not found"));
            }

            return SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SectionCard(
                    title: "Customer",
                    children: [
                      InfoRow(icon: Icons.person, label: "Name", value: details.customerName ?? 'N/A'),
                      InfoRow(icon: Icons.phone, label: "Phone", value: details.customerPhone ?? 'N/A'),
                      InfoRow(icon: Icons.email, label: "Email", value: details.customerEmail ?? 'N/A'),
                    ],
                  ),
                  SectionCard(
                    title: "Vehicle",
                    children: [
                      InfoRow(icon: Icons.confirmation_number, label: "Vehicle No", value: details.vehicleNo ?? 'N/A'),
                      InfoRow(icon: Icons.directions_car, label: "Model", value: details.vehicleModel ?? 'N/A'),
                      InfoRow(icon: Icons.calendar_today, label: "Year", value: details.vehicleYear?.toString() ?? 'N/A'),
                    ],
                  ),
                  SectionCard(
                    title: "Job",
                    children: [
                      InfoRow(icon: Icons.tag, label: "Job ID", value: details.jobId),
                      InfoRow(icon: Icons.description, label: "Description", value: details.description),
                      InfoRow(icon: Icons.flag, label: "Status", value: _status),
                      InfoRow(icon: Icons.priority_high, label: "Priority", value: details.priority),
                      const SizedBox(height: 8),
                      QuickActions(job: widget.job),
                    ],
                  ),
                  SectionCard(
                    title: "Assigned Parts",
                    children: [
                      PartsList(
                        parts: details.parts,
                        partsTotal: details.partsTotal,
                        readOnly: isCompleted,
                        onAddParts: () async {
                          final result = await Navigator.push<bool>(
                            context,
                            MaterialPageRoute(
                              builder: (_) => JobPartScreen(jobId: widget.job.jobId),
                            ),
                          );
                          if (result == true) _refresh();
                        },
                        onRemovePart: (p) async {
                          if (isCompleted) return;
                          debugPrint('Delete request => jobId=${widget.job.jobId}, partId=${p.partId}');
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('Remove part?'),
                              content: Text('Remove "${p.name}" from this job?'),
                              actions: [
                                TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('Remove')),
                              ],
                            ),
                          );

                          if (ok != true) return;

                          try {
                            await _service.removeJobPart(jobId: widget.job.jobId, partId: p.partId);
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Part removed')));
                            _refresh();
                          } catch (e) {
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: $e')));
                          }
                        },
                      ),
                    ],
                  ),
                  SectionCard(
                    title: "Customer Sign-off",
                    children: [
                      if (details.signatureUrl != null) ...[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            details.signatureUrl!,
                            height: 160,
                            fit: BoxFit.contain,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          details.signedAt != null
                              ? "Signed at: ${details.signedAt!.toLocal()}"
                              : "Signed",
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ] else
                        const Text("No signature captured."),
                    ],
                  ),
                  SectionCard(
                    title: "Service History",
                    children: () {
                      final legacy = (details.serviceHistory ?? '').trim();
                      final hasLegacy = legacy.isNotEmpty;
                      final hasDated = details.history.isNotEmpty;

                      if (!hasLegacy && !hasDated) {
                        return const [Text("No previous service records.")];
                      }

                      final widgets = <Widget>[];

                      if (hasLegacy) {
                        widgets.add(Text(legacy));
                      }

                      if (hasLegacy && hasDated) {
                        widgets.add(const SizedBox(height: 8));
                        widgets.add(const Divider());
                      }

                      if (hasDated) {
                        widgets.addAll(details.history.map((h) {
                          final d = h.date;
                          final dateStr = d != null
                              ? "${d.year.toString().padLeft(4, '0')}-"
                              "${d.month.toString().padLeft(2, '0')}-"
                              "${d.day.toString().padLeft(2, '0')}"
                              : '—';
                          return ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            leading: const Icon(Icons.event, color: Colors.teal),
                            title: Text(h.description.isEmpty ? '(No description)' : h.description),
                            subtitle: Text("Job: ${h.jobId} • Status: ${h.status}"),
                            trailing: Text(dateStr),
                          );
                        }));
                      }

                      return widgets;
                    }(),
                  ),

                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

extension _JobCopy on Job {
  Job copyWith({
    String? status,
  }) {
    return Job(
      jobId: jobId,
      description: description,
      status: status ?? this.status,
      priority: priority,
      assignedMechanic: assignedMechanic,
      vehicleModel: vehicleModel,
      vehicleYear: vehicleYear,
      vehicleNo: vehicleNo,
      createdAt:createdAt,
    );
  }
}
