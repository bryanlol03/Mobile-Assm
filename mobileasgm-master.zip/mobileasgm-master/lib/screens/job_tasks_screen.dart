import 'dart:async';
import 'package:flutter/material.dart';
import '../models/job.dart';
import '../models/job_task.dart';
import '../services/task_service.dart';

class JobTasksScreen extends StatefulWidget {
  final Job job;
  const JobTasksScreen({super.key, required this.job});

  @override
  State<JobTasksScreen> createState() => _JobTasksScreenState();
}

class _JobTasksScreenState extends State<JobTasksScreen> {
  final _service = TaskService();
  late Future<List<JobTask>> _tasksFuture;
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    _reload();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  void _reload() {
    _tasksFuture = _service.fetchTasks(widget.job.jobId);
  }

  Duration _elapsed(JobTask t) {
    final base = Duration(seconds: t.elapsedSeconds);

    if (t.status == 'In Progress' && t.startTime != null) {
      return base + DateTime.now().toUtc().difference(t.startTime!);
    }


    return base;
  }


  Duration _totalDuration(List<JobTask> tasks) {
    return tasks.fold(Duration.zero, (sum, t) => sum + _elapsed(t));
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final s = d.inSeconds % 60;
    if (h > 0) return '${h}h ${m}m ${s}s';
    if (m > 0) return '${m}m ${s}s';
    return '${s}s';
  }

  Future<void> _start(JobTask t) async {
    await _service.startTask(t.taskId);
    setState(_reload);
  }

  Future<void> _pause(JobTask t) async {
    await _service.pauseTask(t.taskId, t.startTime, t.elapsedSeconds);
    setState(_reload);
  }

  Future<void> _complete(JobTask t) async {
    await _service.completeTask(t.taskId, t.startTime, t.elapsedSeconds);
    setState(_reload);
  }

  Future<void> _addTaskDialog() async {
    final ctl = TextEditingController();
    bool autoStart = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            title: const Text('New Task'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: ctl,
                  decoration: const InputDecoration(labelText: 'Task name'),
                ),
                Row(
                  children: [
                    Checkbox(
                      value: autoStart,
                      onChanged: (v) =>
                          setStateDialog(() => autoStart = v ?? false),
                    ),
                    const Text("Start immediately"),
                  ],
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancel')),
              ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Add')),
            ],
          );
        },
      ),
    );

    if (ok == true && ctl.text.trim().isNotEmpty) {
      await _service.createTask(widget.job.jobId, ctl.text.trim(),
          autoStart: autoStart);
      setState(_reload);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isCompleted = widget.job.status == 'Completed';
    return Scaffold(
      appBar: AppBar(
        title: Text('Tasks for ${widget.job.jobId}'),
        actions: [
          if (!isCompleted)
            IconButton(onPressed: _addTaskDialog, icon: const Icon(Icons.add)),
        ],
      ),
      body: FutureBuilder<List<JobTask>>(
        future: _tasksFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Error: ${snap.error}'));
          }
          final tasks = snap.data ?? [];
          if (tasks.isEmpty) {
            return const Center(child: Text('No tasks yet.'));
          }

          final total = _totalDuration(tasks);

          return Column(
            children: [
              // ✅ Total Duration card
              Card(
                color: Colors.black,
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Total Duration",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        _fmt(total),
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),

              if (isCompleted)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: MaterialBanner(
                    content: const Text('Job is Completed — tasks are read-only.'),
                    leading: const Icon(Icons.lock, color: Colors.amber),
                    actions: const [SizedBox.shrink()],
                    backgroundColor: Colors.black54,
                  ),
                ),

              // ✅ Task list
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemBuilder: (context, i) {
                    final t = tasks[i];
                    final elapsed = _elapsed(t);
                    return Card(
                      child: ListTile(
                        title: Text(t.taskName),
                        subtitle: Text(
                            'Status: ${t.status} · Elapsed: ${_fmt(elapsed)}'),
                        trailing: (!isCompleted)
                        ? Wrap(
                          spacing: 8,
                          children: [
                            if (t.status == 'Not Started' || t.status == 'Paused')
                              IconButton(
                                tooltip: 'Start',
                                icon: const Icon(Icons.play_arrow,
                                    color: Colors.green),
                                onPressed: () => _start(t),
                              ),
                            if (t.status == 'In Progress')
                              IconButton(
                                tooltip: 'Pause',
                                icon:
                                const Icon(Icons.pause, color: Colors.amber),
                                onPressed: () => _pause(t),
                              ),
                            if (t.status != 'Completed')
                              IconButton(
                                tooltip: 'Complete',
                                icon: const Icon(Icons.check,
                                    color: Colors.blue),
                                onPressed: () => _complete(t),
                              ),
                          ],
                        )
                            :null,
                      ),
                    );
                  },
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemCount: tasks.length,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
