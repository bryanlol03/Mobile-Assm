import 'package:flutter/material.dart';
import '../services/job_service.dart';
import '../services/session_login.dart';
import '../widgets/bottom_nav_bar.dart';
import '../models/job.dart';
import 'job_details_screen.dart';
import '../widgets/job_card.dart';

const kAllowedStatuses = <String>[
  'Pending',
  'In Progress',
  'On Hold',
  'Completed',
];

class JobsScreen extends StatefulWidget {
  const JobsScreen({super.key});

  @override
  State<JobsScreen> createState() => _JobsScreenState();
}

class _JobsScreenState extends State<JobsScreen> {
  final JobService _jobService = JobService();
  late Future<List<Job>> _currentJobsFuture;

  String mechanicId = '';
  String mechanicName = '';
  bool isSessionLoaded = false;

  String? _statusFilter;
  DateTime? _fromDate;
  DateTime? _toDate;

  @override
  void initState() {
    super.initState();
    _loadSessionAndJobs();
  }

  Future<void> _loadSessionAndJobs() async {
    final id = await SessionLogin.getMechanicId();
    final name = await SessionLogin.getMechanicName();
    if (id != null && name != null) {
      final trimmedId = id.trim();
      setState(() {
        mechanicId = trimmedId;
        mechanicName = name;
        _currentJobsFuture = _jobService.getCurrentJobsForMechanic(trimmedId);
        isSessionLoaded = true;
      });
    } else {
      setState(() => isSessionLoaded = true);
    }
  }

  // Date range picker
  Future<void> _pickDateRange() async {
    final now = DateTime.now();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 5, 1, 1),
      lastDate: DateTime(now.year + 1, 12, 31),
      initialDateRange: DateTimeRange(
        start: _fromDate ?? now.subtract(const Duration(days: 30)),
        end: _toDate ?? now,
      ),
    );
    if (range != null) {
      setState(() {
        _fromDate = DateTime(range.start.year, range.start.month, range.start.day);
        _toDate = DateTime(range.end.year, range.end.month, range.end.day, 23, 59, 59);
      });
    }
  }

  void _clearFilters() {
    setState(() {
      _statusFilter = null;
      _fromDate = null;
      _toDate = null;
    });
  }

  String _dateLabel(DateTime? d) {
    if (d == null) return '—';
    return "${d.year.toString().padLeft(4, '0')}-"
        "${d.month.toString().padLeft(2, '0')}-"
        "${d.day.toString().padLeft(2, '0')}";
  }

  List<Job> _applyFilters(List<Job> jobs) {
    Iterable<Job> out = jobs;

    if (_statusFilter != null) {
      out = out.where((j) => j.status.toLowerCase() == _statusFilter!.toLowerCase());
    }
    if (_fromDate != null) {
      out = out.where((j) => j.createdAt.isAfter(_fromDate!.subtract(const Duration(milliseconds: 1))));
    }
    if (_toDate != null) {
      out = out.where((j) => j.createdAt.isBefore(_toDate!.add(const Duration(milliseconds: 1))));
    }

    return out.toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("$mechanicName's Current Jobs")),
      bottomNavigationBar: const BottomNavBar(currentIndex: 1),
      body: !isSessionLoaded
          ? const Center(child: CircularProgressIndicator())
          : FutureBuilder<List<Job>>(
        future: _currentJobsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          final allJobs = snapshot.data ?? [];
          if (allJobs.isEmpty) {
            return const Center(child: Text("No current jobs assigned."));
          }

          final jobs = _applyFilters(allJobs);
          final grouped = <String, List<Job>>{};
          for (final job in jobs) {
            grouped.putIfAbsent(job.status, () => []).add(job);
          }
          final flattened = <Map<String, dynamic>>[];
          grouped.forEach((status, jobList) {
            flattened.add({'isHeader': true, 'status': status});
            for (final job in jobList) {
              flattened.add({'isHeader': false, 'job': job});
            }
          });

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    SizedBox(
                      width: 220,
                      child: DropdownButtonFormField<String?>(
                        value: _statusFilter, // String? in your state
                        isDense: true,
                        decoration: const InputDecoration(
                          labelText: 'Status',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem<String?>(value: null, child: Text('All')),
                          DropdownMenuItem<String?>(value: 'Pending', child: Text('Pending')),
                          DropdownMenuItem<String?>(value: 'In Progress', child: Text('In Progress')),
                          DropdownMenuItem<String?>(value: 'On Hold', child: Text('On Hold')),
                          DropdownMenuItem<String?>(value: 'Completed', child: Text('Completed')),
                        ],
                        onChanged: (val) => setState(() => _statusFilter = val),
                      ),
                    ),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.date_range),
                      label: Text(
                        (_fromDate == null && _toDate == null)
                            ? 'Pick Date Range'
                            : '${_dateLabel(_fromDate)} → ${_dateLabel(_toDate)}',
                      ),
                      onPressed: _pickDateRange,
                    ),
                    TextButton.icon(
                      icon: const Icon(Icons.filter_alt_off),
                      label: const Text('Reset'),
                      onPressed: _clearFilters,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Divider(height: 1),

              Expanded(
                child: ListView.builder(
                  itemCount: flattened.length,
                  itemBuilder: (context, index) {
                    final item = flattened[index];
                    if (item['isHeader'] == true) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Text(
                          item['status'],
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent,
                          ),
                        ),
                      );
                    } else {
                      final Job job = item['job'];
                      return JobCard(
                        job: job,
                        onTap: () async {
                          final updatedJob = await Navigator.push<Job>(
                            context,
                            MaterialPageRoute(
                              builder: (_) => JobDetailsScreen(job: job),
                            ),
                          );
                          if (updatedJob != null) {
                            setState(() {
                              _currentJobsFuture =
                                  _jobService.getCurrentJobsForMechanic(mechanicId);
                            });
                          }
                        },
                      );
                    }
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
