import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:signature/signature.dart';

import '../models/job.dart';
import '../services/job_service.dart';

class JobCompletionScreen extends StatefulWidget {
  final Job job;
  final String? customerId;

  const JobCompletionScreen({
    super.key,
    required this.job,
    this.customerId,
  });

  @override
  State<JobCompletionScreen> createState() => _JobCompletionScreenState();
}

Future<Uint8List> _applyWatermark(
    Uint8List pngBytes, {
      String text = '@GreenStem',
      double opacity = 0.12,
      double angleRad = -0.35, // ~ -20°
    }) async {
  final codec = await ui.instantiateImageCodec(pngBytes);
  final frame = await codec.getNextFrame();
  final img = frame.image;

  final width = img.width.toDouble();
  final height = img.height.toDouble();

  final recorder = ui.PictureRecorder();
  final canvas = Canvas(recorder);
  final paint = Paint();

  canvas.drawImage(img, Offset.zero, paint);

  final fontSize = width * 0.12;

  final textPainter = TextPainter(
    text: TextSpan(
      text: text,
      style: TextStyle(
        color: Colors.black.withOpacity(opacity),
        fontSize: fontSize,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.2,
      ),
    ),
    textDirection: TextDirection.ltr,
    textAlign: TextAlign.center,
  )..layout(maxWidth: width);

  canvas.save();
  canvas.translate(width / 2, height / 2);
  canvas.rotate(angleRad);
  textPainter.paint(
    canvas,
    Offset(-textPainter.width / 2, -textPainter.height / 2),
  );
  canvas.restore();

  final picture = recorder.endRecording();
  final watermarked = await picture.toImage(img.width, img.height);
  final byteData =
  await watermarked.toByteData(format: ui.ImageByteFormat.png);
  return byteData!.buffer.asUint8List();
}

class _JobCompletionScreenState extends State<JobCompletionScreen> {
  final SignatureController _signatureController = SignatureController(
    penStrokeWidth: 3,
    penColor: Colors.black,
    exportBackgroundColor: Colors.white,
  );

  final _service = JobService();
  bool _saving = false;

  Future<void> _complete() async {
    if (_signatureController.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please provide a signature!')),
      );
      return;
    }

    setState(() => _saving = true);
    try {
      final Uint8List? png = await _signatureController.toPngBytes();
      if (png == null) throw Exception('Failed to export signature.');

      final Uint8List marked = await _applyWatermark(
        png,
        text: '@GreenStem', // customize if needed
        opacity: 0.12,
      );

      final url = await _service.uploadSignature(
        bytes: marked,
        jobId: widget.job.jobId,
      );

      if (widget.customerId != null && widget.customerId!.isNotEmpty) {
        await _service.saveJobSignoff(
          jobId: widget.job.jobId,
          customerId: widget.customerId!,
          signatureUrl: url,
        );
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Signature saved ✅')),
      );

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _signatureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const dark = Colors.black;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: dark,
        elevation: 0,
        title: Text(
          "Complete Job: ${widget.job.jobId}",
          style: const TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 6),
              const Center(
                child: CircleAvatar(
                  radius: 36,
                  backgroundColor: Color(0xFFE8EAF6),
                  child: Icon(Icons.engineering, size: 40, color: Colors.black87),
                ),
              ),
              const SizedBox(height: 20),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: dark, width: 1.2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Job: ${widget.job.description}",
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text("Status: ${widget.job.status}",
                        style: const TextStyle(color: Colors.black)),
                    Text("Priority: ${widget.job.priority}",
                        style: const TextStyle(color: Colors.black)),
                    Text("Mechanic: ${widget.job.assignedMechanic}",
                        style: const TextStyle(color: Colors.black)),
                    if (widget.job.vehicleModel != null)
                      Text(
                        "Vehicle: ${widget.job.vehicleModel} (${widget.job.vehicleYear ?? '-'})",
                        style: const TextStyle(color: Colors.black),
                      ),
                    if (widget.job.vehicleNo != null)
                      Text("Vehicle No: ${widget.job.vehicleNo}",
                          style: const TextStyle(color: Colors.black)),
                  ],
                ),
              ),

              // ---- Signature ----
              const Text(
                "Customer Signature",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 10),

              Container(
                width: 420,
                height: 220,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: dark, width: 1.5),
                ),
                child: Signature(
                  controller: _signatureController,
                  backgroundColor: Colors.white,
                ),
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: dark,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      onPressed: _saving ? null : _complete,
                      child: _saving
                          ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                          : const Text("Sign & Finish",
                          style: TextStyle(fontSize: 14)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: dark,
                        side: const BorderSide(color: dark, width: 1.2),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      onPressed:
                      _saving ? null : () => _signatureController.clear(),
                      child: const Text("Clear", style: TextStyle(fontSize: 14)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
