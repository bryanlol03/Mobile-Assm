import 'package:flutter/material.dart';
import '../services/session_login.dart';
import '../services/job_service.dart';
import '../widgets/bottom_nav_bar.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _pageSize = 5;
  String mechanicName = '';
  String mechanicId = '';
  bool isLoaded = false;

  final _jobService = JobService();
  late Future<Map<String, int>> _jobCountsFuture;
  late Future<List<Map<String, dynamic>>> _inProgressJobsFuture;

  @override
  void initState() {
    super.initState();
    _loadSession();
  }

  Future<void> _loadSession() async {
    final id = await SessionLogin.getMechanicId();
    final name = await SessionLogin.getMechanicName();

    setState(() {
      mechanicId = id ?? '';
      mechanicName = name ?? '';
      isLoaded = true;
      _jobCountsFuture = _jobService.fetchJobCounts(mechanicId);
      _inProgressJobsFuture = _jobService.fetchInProgressJobs(mechanicId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard"), centerTitle: true),
      bottomNavigationBar: const BottomNavBar(currentIndex: 0),
      body: isLoaded
          ? FutureBuilder<Map<String, int>>(
              future: _jobCountsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text("Error: ${snapshot.error}"));
                } else if (!snapshot.hasData) {
                  return const Center(child: Text("No data available"));
                }

                final counts = snapshot.data!;
                return SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        color: Colors.blue.shade50,
                        child: ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: Colors.blue,
                            child: Icon(Icons.engineering, color: Colors.white),
                          ),
                          title: const Text(
                            "Welcome back,",
                            style: TextStyle(fontSize: 14,
                              color: Colors.black,),

                          ),
                          subtitle: Text(
                            mechanicName,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[900],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      Text(
                        "Job Overview",
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 10),

                      Row(
                        children: [
                          _summaryCard(
                            "Pending",
                            counts["Pending"].toString(),
                            Colors.orange,
                            Icons.pending_actions,
                          ),
                          _summaryCard(
                            "In Progress",
                            counts["In Progress"].toString(),
                            Colors.blue,
                            Icons.build_circle,
                          ),
                          _summaryCard(
                            "Completed",
                            counts["Completed"].toString(),
                            Colors.green,
                            Icons.check_circle,
                          ),
                        ],
                      ),

                      const SizedBox(height: 30),

                      Text(
                        "Important Task",
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 10),

                      FutureBuilder<List<Map<String, dynamic>>>(
                        future: _inProgressJobsFuture,
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          } else if (snapshot.hasError) {
                            return Center(
                              child: Text("Error: ${snapshot.error}"),
                            );
                          } else if (!snapshot.hasData ||
                              snapshot.data!.isEmpty) {
                            return const Text("No jobs in progress.");
                          }

                          final jobs = snapshot.data!;

                          final visibleJobs = jobs.take(_pageSize).toList();

                          return Column(
                            children: [
                              ...visibleJobs.map((job) {
                                final isImportant =
                                    job['priority']?.toString().toLowerCase() ==
                                    'high';

                                return Card(
                                  color: isImportant
                                      ? Colors.red.shade50
                                      : null,
                                  margin: const EdgeInsets.only(bottom: 10),
                                  child: ListTile(
                                    leading: Icon(
                                      isImportant
                                          ? Icons.priority_high
                                          : Icons.work,
                                      color: isImportant
                                          ? Colors.red
                                          : Colors.blue,
                                    ),
                                    title: Text(job['job_id'] ?? 'Untitled'),
                                    subtitle: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          job['description'] ??
                                              'No description',
                                        ),
                                        if (isImportant)
                                          const Text(
                                            "⚡ Important Task",
                                            style: TextStyle(
                                              color: Colors.red,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12,
                                            ),
                                          ),
                                      ],
                                    ),
                                    trailing: Text(
                                      job['estimated_time'] ?? '',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ),
                                );
                              }),

                              if (jobs.length > _pageSize)
                                TextButton(
                                  onPressed: () {
                                    setState(() {
                                      _pageSize += 5;
                                    });
                                  },
                                  child: const Text("Load More"),
                                ),
                            ],
                          );
                        },
                      ),
                    ],
                  ),
                );
              },
            )
          : const Center(child: CircularProgressIndicator()),
    );
  }

  Widget _summaryCard(String title, String count, Color color, IconData icon) {
    return Expanded(
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, color: color, size: 32),
              const SizedBox(height: 8),
              Text(
                count,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
