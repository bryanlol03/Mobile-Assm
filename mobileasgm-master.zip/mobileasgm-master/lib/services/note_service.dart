import 'dart:io' show File;
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;
import 'package:supabase_flutter/supabase_flutter.dart';

class NoteService {
  final SupabaseClient _client = Supabase.instance.client;
  static const _bucket = 'job_photo';

  Future<String?> uploadPhoto(File file, {required String jobId}) async {
    if (kIsWeb) {
      throw Exception('Use uploadPhotoBytes on web.');
    }
    final ext = p.extension(file.path).replaceFirst('.', '').toLowerCase();
    final mimeType = lookupMimeType(file.path) ?? 'image/jpeg';
    final filename = '${DateTime.now().millisecondsSinceEpoch}.${ext.isEmpty ? 'jpg' : ext}';
    final path = 'jobs/$jobId/$filename';

    await _client.storage
        .from(_bucket)
        .upload(path, file, fileOptions: FileOptions(contentType: mimeType, upsert: false));

    return _client.storage.from(_bucket).getPublicUrl(path);
  }

  Future<String?> uploadPhotoBytes(
      Uint8List bytes, {
        required String jobId,
        required String originalFileName,
      }) async {
    final ext = p.extension(originalFileName).replaceFirst('.', '').toLowerCase();
    final mimeType = lookupMimeType(originalFileName) ?? 'image/jpeg';
    final filename = '${DateTime.now().millisecondsSinceEpoch}.${ext.isEmpty ? 'jpg' : ext}';
    final path = 'jobs/$jobId/$filename';

    await _client.storage
        .from(_bucket)
        .uploadBinary(path, bytes, fileOptions: FileOptions(contentType: mimeType, upsert: false));

    return _client.storage.from(_bucket).getPublicUrl(path);
  }

  Future<Map<String, dynamic>?> addNote({
    required String jobId,
    required String mechanicId,
    String? noteText,
    String? photoUrl,
  }) async {
    final row = await _client
        .from('job_notes')
        .insert({
      'job_id': jobId,
      'mechanic_id': mechanicId,
      'note_text': noteText,
      'photo_url': photoUrl,
    })
        .select()
        .maybeSingle();
    return row;
  }

  Future<List<Map<String, dynamic>>> fetchNotesRaw(String jobId) async {
    final data = await _client
        .from('job_notes')
        .select()
        .eq('job_id', jobId)
        .order('created_at', ascending: false);
    if (data == null) return [];
    return (data as List).whereType<Map<String, dynamic>>().toList();
  }
}
