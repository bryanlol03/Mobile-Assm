import 'package:shared_preferences/shared_preferences.dart';

class SessionLogin {
  static const _keyMechanicId = 'mechanic_id';
  static const _keyMechanicName = 'mechanic_name';

  static Future<void> saveMechanicSession(String mechanicId, String mechanicName) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyMechanicId, mechanicId);
    await prefs.setString(_keyMechanicName, mechanicName);
  }

  static Future<String?> getMechanicId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyMechanicId);
  }

  static Future<String?> getMechanicName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyMechanicName);
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_keyMechanicId);
    await prefs.remove(_keyMechanicName);
  }
}
