import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  final _client = Supabase.instance.client;

  Future<Map<String, dynamic>?> loginMechanic(String email,
      String password) async {
    try {
      final response = await Supabase.instance.client.rpc(
        'login_mechanic',
        params: {
          'p_email': email,
          'p_password': password,
        },
      );

      print("RPC Response: $response");

      if (response == null) return null;

      if (response is List && response.isNotEmpty) {
        return response.first as Map<String, dynamic>;
      }

      if (response is Map<String, dynamic>) {
        return response;
      }

      return null;
    } catch (e) {
      print('Login error: $e');
      return null;
    }
  }
}
