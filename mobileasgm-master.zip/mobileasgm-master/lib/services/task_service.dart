import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/job_task.dart';

class TaskService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<JobTask>> fetchTasks(String jobId) async {
    final data = await _client
        .from('job_tasks')
        .select(
        'task_id, job_id, task_name, status, start_time, end_time, notes, elapsed_seconds')
        .eq('job_id', jobId)
        .order('task_id', ascending: true);

    print("📦 Raw tasks for $jobId: $data");

    if (data == null) return [];
    return (data as List)
        .whereType<Map<String, dynamic>>()
        .map((j) => JobTask.fromJson(j))
        .toList();
  }

  Future<JobTask?> createTask(String jobId, String taskName,
      {bool autoStart = false}) async {
    final now = DateTime.now().toUtc();

    final insertData = {
      'job_id': jobId,
      'task_name': taskName,
      'status': autoStart ? 'In Progress' : 'Not Started',
      'start_time': autoStart ? now.toIso8601String() : null,
      'elapsed_seconds': 0,
    };

    final row =
    await _client.from('job_tasks').insert(insertData).select().maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }

  Future<JobTask?> startTask(String taskId) async {
    final now = DateTime.now().toUtc();

    final row = await _client
        .from('job_tasks')
        .update({
      'status': 'In Progress',
      'start_time': now.toIso8601String(), // always "resume from now"
    })
        .eq('task_id', taskId)
        .select()
        .maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }



  Future<JobTask?> pauseTask(
      String taskId, DateTime? startTime, int elapsedSoFar) async {
    final now = DateTime.now().toUtc();
    int additional = 0;
    if (startTime != null) {
      additional = now.difference(startTime).inSeconds;
    }

    final row = await _client
        .from('job_tasks')
        .update({
      'status': 'Paused',
      'end_time': now.toIso8601String(),
      'elapsed_seconds': elapsedSoFar + additional,
      'start_time': null,
    })
        .eq('task_id', taskId)
        .select()
        .maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }
  Future<JobTask?> resumeTask(String taskId) async {
    final now = DateTime.now().toUtc();

    final row = await _client
        .from('job_tasks')
        .update({
      'status': 'In Progress',
      'start_time': now.toIso8601String(),
    })
        .eq('task_id', taskId)
        .select()
        .maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }

  Future<JobTask?> completeTask(
      String taskId, DateTime? startTime, int elapsedSoFar) async {
    final now = DateTime.now().toUtc();
    int additional = 0;
    if (startTime != null) {
      additional = now.difference(startTime).inSeconds;
    }

    final row = await _client
        .from('job_tasks')
        .update({
      'status': 'Completed',
      'end_time': now.toIso8601String(),
      'elapsed_seconds': elapsedSoFar + additional,
      'start_time': null,
    })
        .eq('task_id', taskId)
        .select()
        .maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }

  Future<JobTask?> addTaskNote(String taskId, String note) async {
    final row = await _client
        .from('job_tasks')
        .update({'notes': note})
        .eq('task_id', taskId)
        .select()
        .maybeSingle();

    return row == null ? null : JobTask.fromJson(row);
  }
}
