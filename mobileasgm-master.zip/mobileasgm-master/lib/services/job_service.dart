import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/job.dart';
import '../models/job_details.dart';
import '../services/session_login.dart';
import '../models/part.dart';
import '../models/selected_part.dart';
import 'dart:typed_data';

class JobService {
  final SupabaseClient _client = Supabase.instance.client;

  static const _allowedStatuses = {
    'Pending',
    'In Progress',
    'On Hold',
    'Completed',
  };

  Future<Map<String, int>> fetchJobCounts(String mechanicId) async {
    try {
      final data = await _client
          .from('jobs')
          .select('status')
          .eq('assigned_mechanic', mechanicId);

      if (data == null) return {};

      final Map<String, int> counts = {};
      for (final row in (data as List)) {
        final status = row['status'] as String?;
        if (status != null) {
          counts[status] = (counts[status] ?? 0) + 1;
        }
      }

      for (final s in _allowedStatuses) {
        counts.putIfAbsent(s, () => 0);
      }

      return counts;
    } catch (e) {
      throw Exception('Failed to fetch job counts: $e');
    }
  }

  Future<List<Map<String, dynamic>>> fetchInProgressJobs(String mechanicId) async {
    try {
      final data = await _client
          .from('jobs')
          .select('job_id, vehicle_id, description, status')
          .eq('assigned_mechanic', mechanicId)
          .eq('status', 'In Progress');

      if (data == null) return [];
      return List<Map<String, dynamic>>.from(data as List);
    } catch (e) {
      throw Exception('Failed to fetch in-progress jobs: $e');
    }
  }

  Future<List<Job>> getCurrentJobsForMechanic(String mechanicId) async {
    try {
      final data = await _client
          .from('jobs')
          .select('''
            job_id,
            description,
            status,
            priority,
            assigned_mechanic,
            created_at,  
            vehicles (
              model,
              year,
              vehicle_no
            )
          ''')
          .eq('assigned_mechanic', mechanicId)
          .order('created_at', ascending: false);

      if (data == null) return [];
      return (data as List)
          .whereType<Map<String, dynamic>>()
          .map((json) => Job.fromJson(json))
          .toList();
    } catch (error) {
      throw Exception('Failed to fetch jobs: $error');
    }
  }

  Future<JobDetails?> getJobDetailsById(String jobId) async {
    try {
      final data = await _client
          .from('jobs')
          .select('''
            job_id,
            description,
            status,
            priority,
            vehicle_id,
            start_time,
            end_time,
            vehicles (
              model,
              year,
              vehicle_no,
              service_history,
              customers (
              customer_id,
                name,
                phone,
                email
              )
            ),
            job_parts (
        part_id,
        quantity_used,
        parts ( name, unit_price )
      ),
      job_signoffs:job_signoffs!job_signoffs_job_id_fkey (
        signature_url,
        signed_at
      )
    ''')
          .eq('job_id', jobId)
          .order('signed_at', referencedTable: 'job_signoffs', ascending: false)
          .limit(1, referencedTable: 'job_signoffs')
          .maybeSingle();

      if (data == null) return null;

      List<Map<String, dynamic>> entries = [];
      final vehicleId = data['vehicle_id'] as String?;
      if (vehicleId != null && vehicleId.isNotEmpty) {
        final hist = await _client
            .from('jobs')
            .select('job_id, description, status, end_time, created_at')
            .eq('vehicle_id', vehicleId)
            .neq('job_id', jobId)
            .order('end_time', ascending: false)
            .order('created_at', ascending: false);

        entries = List<Map<String, dynamic>>.from(hist as List);
      }

      return JobDetails.fromJson({
        ...data,
        'job_parts': data['job_parts'],
        'vehicles': data['vehicles'],
        'service_entries': entries,
      });
    } catch (e) {
      throw Exception('Failed to fetch job details: $e');
    }
  }
  Future<void> removeJobPart({
    required String jobId,
    required String partId,
  }) async {
    final res = await _client
        .from('job_parts')
        .delete()
        .eq('job_id', jobId)
        .eq('part_id', partId)
        .select();

    if (res is List && res.isEmpty) {
      throw Exception('No matching job_part row (job_id=$jobId, part_id=$partId). '
          'Check exact IDs and RLS policy.');
    }
  }

  Future<void> updateJobStatus({
    required String jobId,
    required String newStatus,
  }) async {
    if (!_allowedStatuses.contains(newStatus)) {
      throw Exception('Invalid status: $newStatus');
    }

    final mechanicId = (await SessionLogin.getMechanicId())?.trim();
    if (mechanicId == null || mechanicId.isEmpty) {
      throw Exception('No mechanic session');
    }

    try {
      final res = await _client.rpc(
        'rpc_update_job_status',
        params: {
          'p_job_id': jobId,
          'p_mechanic_id': mechanicId,
          'p_new_status': newStatus,
        },
      );

      if (res == null) {
        throw Exception('RPC returned null');
      }
    } on PostgrestException catch (e) {
      throw Exception(
        'DB error: ${e.message} (code ${e.code}) ${e.details ?? ''}',
      );
    }
  }

  Future<String> uploadSignature({
    required Uint8List bytes,
    required String jobId,
    bool useSignedUrl = false,
    Duration signedUrlTTL = const Duration(hours: 1),
  }) async {
    final bucket = _client.storage.from('signatures');
    final filename = '${DateTime.now().millisecondsSinceEpoch}.png';
    final path = '$jobId/$filename';

    await bucket.uploadBinary(
      path,
      bytes,
      fileOptions: const FileOptions(
        contentType: 'image/png',
        upsert: true,
      ),
    );

    final publicUrl = bucket.getPublicUrl(path);

    if (!useSignedUrl) return publicUrl;

    final signed = await bucket.createSignedUrl(path, signedUrlTTL.inSeconds);
    return signed;
  }

  Future<void> saveJobSignoff({
    required String jobId,
    required String customerId,
    required String signatureUrl,
  }) async {
    final res = await _client.from('job_signoffs').insert({
      'job_id': jobId,
      'customer_id': customerId,
      'signature_url': signatureUrl,
    }).select();

    if (res == null) {
    }
  }

  Future<List<Part>> fetchAvailableParts() async {
    final response = await _client
        .from('parts')
        .select('part_id, name, stock_quantity, unit_price')
        .gt('stock_quantity', 0);

    if (response == null) return [];
    final List data = response as List;
    return data.map((e) => Part.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> addJobParts({
    required String jobId,
    required List<SelectedPart> selectedParts,
  }) async {
    if (selectedParts.isEmpty) {
      throw Exception('No parts selected');
    }

    final rows = selectedParts.map((sp) {
      return {
        'job_id': jobId,
        'part_id': sp.part.partId,
        'quantity_used': sp.quantity,
      };
    }).toList();

    final res = await _client.from('job_parts').insert(rows).select();
    if (res == null) {
      throw Exception('Failed to add job parts');
    }
  }
  Future<List<Map<String, dynamic>>> fetchJobsByStatus(
      String mechanicId,
      String status, {
        int? limit,
      }) async {
    try {
      final query = _client
          .from('jobs')
          .select('job_id, vehicle_id, description, status, priority, created_at')
          .eq('assigned_mechanic', mechanicId)
          .eq('status', status)
          .order('created_at', ascending: false);

      if (limit != null) {
        query.limit(limit);
      }

      final data = await query;
      if (data == null) return [];
      return List<Map<String, dynamic>>.from(data as List);
    } catch (e) {
      throw Exception('Failed to fetch $status jobs: $e');
    }
  }


}
