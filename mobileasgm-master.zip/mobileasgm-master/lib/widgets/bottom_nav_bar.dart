import 'package:flutter/material.dart';
import '../services/session_login.dart';
import '../screens/dashboard_screen.dart';
import '../screens/jobs_screen.dart';
import '../screens/profile_screen.dart';

class BottomNavBar extends StatefulWidget {
  final int currentIndex;

  const BottomNavBar({
    super.key,
    required this.currentIndex,
  });

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  String mechanicId = '';
  String mechanicName = '';
  bool isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadMechanicSession();
  }

  Future<void> _loadMechanicSession() async {
    final id = await SessionLogin.getMechanicId();
    final name = await SessionLogin.getMechanicName();

    setState(() {
      mechanicId = id ?? '';
      mechanicName = name ?? '';
      isLoaded = true;
    });
  }

  void _onItemTapped(BuildContext context, int index) {
    if (!isLoaded || index == widget.currentIndex) return;

    Widget destination;
    switch (index) {
      case 0:
        destination = const DashboardScreen();
        break;
      case 1:
        destination = const JobsScreen();
        break;
      case 2:
        destination = const ProfileScreen();
        break;
      default:
        destination = const DashboardScreen();
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => destination),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: widget.currentIndex,
      onTap: (index) => _onItemTapped(context, index),
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.dashboard),
          label: "Dashboard",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.work),
          label: "Jobs",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: "Profile",
        ),
      ],
    );
  }
}
