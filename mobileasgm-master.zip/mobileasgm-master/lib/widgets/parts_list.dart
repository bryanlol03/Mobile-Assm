import 'package:flutter/material.dart';
import '../models/job_part.dart'; // your JobPart model

class PartsList extends StatelessWidget {
  final List<JobPart> parts;
  final VoidCallback onAddParts;
  final num partsTotal;
  final void Function(JobPart part)? onRemovePart;
  final bool readOnly;

  const PartsList({
    super.key,
    required this.parts,
    required this.onAddParts,
    required this.partsTotal,
    this.onRemovePart,
    this.readOnly = false,
  });

  Widget build(BuildContext context) {
    return Column(
      children: [
        if (!readOnly)
          OutlinedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add Parts'),
            onPressed: onAddParts,
          ),
        if (parts.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8.0),
            child: Text('No parts assigned.'),
          ),
        if (parts.isNotEmpty) ...[
          const SizedBox(height: 8),
          ...parts.map((p) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.build, color: Colors.orange),
            title: Text(p.name),
            subtitle: Text('Qty: ${p.quantity} • Unit: ${p.unitPrice ?? '-'}'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Total: ${p.lineTotal.toStringAsFixed(2)}'),
                if (!readOnly && onRemovePart != null) ...[
                  const SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Remove',
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () => onRemovePart!(p),
                  ),
                ],
              ],
            ),
          )),
          const Divider(),
          Align(
            alignment: Alignment.centerRight,
            child: Text(
              "Parts total: ${partsTotal.toStringAsFixed(2)}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ],
    );
  }
}

