import 'package:flutter/material.dart';

class InfoTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String text;

  const InfoTile({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: iconColor),
        title: Text(text.isEmpty ? 'N/A' : text),
      ),
    );
  }
}
