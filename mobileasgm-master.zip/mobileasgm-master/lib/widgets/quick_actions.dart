import 'package:flutter/material.dart';
import '../models/job.dart';
import '../screens/job_tasks_screen.dart';
import '../screens/job_notes_screen.dart';

class QuickActions extends StatelessWidget {
  final Job job;

  const QuickActions({super.key, required this.job});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        OutlinedButton.icon(
          icon: const Icon(Icons.list),
          label: const Text('Manage Tasks'),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => JobTasksScreen(job: job)),
            );
          },
        ),
        OutlinedButton.icon(
          icon: const Icon(Icons.note_add),
          label: const Text('Notes & Photos'),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => JobNotesScreen(job: job)),
            );
          },
        ),
      ],
    );
  }
}
