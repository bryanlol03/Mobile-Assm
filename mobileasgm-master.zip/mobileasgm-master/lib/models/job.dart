// models/job.dart
class Job {
  final String jobId;
  final String description;
  final String status;
  final String priority;
  final String assignedMechanic;
  final String? vehicleModel;
  final int? vehicleYear;
  final String? vehicleNo;
  final DateTime createdAt;

  Job({
    required this.jobId,
    required this.description,
    required this.status,
    required this.priority,
    required this.assignedMechanic,
    this.vehicleModel,
    this.vehicleYear,
    this.vehicleNo,
    required this.createdAt,
  });

  factory Job.fromJson(Map<String, dynamic> json) {
    final vehicle = json['vehicles'] as Map<String, dynamic>?;
    final created = json['created_at'] as String?;
    return Job(
      jobId: json['job_id'] ?? '',
      description: json['description'] ?? '',
      status: json['status'] ?? '',
      priority: json['priority'] ?? '',
      assignedMechanic: json['assigned_mechanic'] ?? '',
      vehicleModel: vehicle?['model'],
      vehicleYear: vehicle?['year'],
      vehicleNo: vehicle?['vehicle_no'],
      createdAt: created != null ? DateTime.parse(created) : DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}
