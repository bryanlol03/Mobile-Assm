class ServiceEntry {
  final String jobId;
  final String description;
  final String status;
  final DateTime? date;

  const ServiceEntry({
    required this.jobId,
    required this.description,
    required this.status,
    this.date,
  });

  factory ServiceEntry.fromJson(Map<String, dynamic> json) {
    DateTime? parseTs(dynamic v) =>
        v == null ? null : DateTime.tryParse(v.toString());
    return ServiceEntry(
      jobId: json['job_id'] ?? '',
      description: json['description'] ?? '',
      status: json['status'] ?? '',
      date: parseTs(json['end_time']) ?? parseTs(json['created_at']),
    );
  }
}
