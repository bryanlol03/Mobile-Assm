// models/selected_part.dart

import 'part.dart';

class SelectedPart {
  final Part part;
  int quantity;

  SelectedPart({
    required this.part,
    required this.quantity,
  });

  num get lineTotal => part.unitPrice * quantity;
}
