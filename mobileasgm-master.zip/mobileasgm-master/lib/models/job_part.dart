// models/job_part.dart
class JobPart {
  final String partId;
  final String name;
  final int quantity;
  final num? unitPrice;

  const JobPart({
    required this.partId,
    required this.name,
    required this.quantity,
    this.unitPrice,
  });

  factory JobPart.fromJson(Map<String, dynamic> json) {
    final parts = json['parts'] as Map<String, dynamic>?;
    return JobPart(
      partId: (json['part_id'] ?? '').toString().trim(),  // trim just in case
      name: parts?['name'] ?? 'Unknown Part',
      quantity: json['quantity_used'] ?? 0,
      unitPrice: parts?['unit_price'],
    );
  }

  num get lineTotal => (unitPrice ?? 0) * quantity;
}
