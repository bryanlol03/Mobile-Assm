class JobNote {
  final String noteId;
  final String jobId;
  final String mechanicId;
  final String? noteText;
  final String? photoUrl;
  final DateTime createdAt;

  JobNote({
    required this.noteId,
    required this.jobId,
    required this.mechanicId,
    this.noteText,
    this.photoUrl,
    required this.createdAt,
  });

  factory JobNote.fromJson(Map<String, dynamic> json) {
    return JobNote(
      noteId: json['note_id'] ?? '',
      jobId: json['job_id'] ?? '',
      mechanicId: json['mechanic_id'] ?? '',
      noteText: json['note_text'],
      photoUrl: json['photo_url'],
      createdAt: DateTime.parse(json['created_at']),
    );
  }
}
