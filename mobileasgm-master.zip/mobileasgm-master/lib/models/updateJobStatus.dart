// services/job_service.dart
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/session_login.dart';

class JobService {
  final SupabaseClient _client = Supabase.instance.client;


  Future<void> updateJobStatus({
    required String jobId,
    required String newStatus,
  }) async {
    final mechanicId = (await SessionLogin.getMechanicId())?.trim();
    if (mechanicId == null || mechanicId.isEmpty) {
      throw Exception('No mechanic session');
    }

    try {
      final res = await _client.rpc('rpc_update_job_status', params: {
        'p_job_id': jobId,
        'p_mechanic_id': mechanicId,
        'p_new_status': newStatus,
      });

      if (res == null) {
        throw Exception('RPC returned null');
      }
    } on PostgrestException catch (e) {
      throw Exception('DB error: ${e.message} (code ${e.code}) ${e.details ?? ''}');
    } catch (e) {
      rethrow;
    }
  }
}
