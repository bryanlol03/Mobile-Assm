class JobTask {
  final String taskId;
  final String jobId;
  final String taskName;
  final String status;
  final DateTime? startTime;
  final DateTime? endTime;
  final String? notes;
  final int elapsedSeconds;

  JobTask({
    required this.taskId,
    required this.jobId,
    required this.taskName,
    required this.status,
    this.startTime,
    this.endTime,
    this.notes,
    this.elapsedSeconds = 0,
  });

  factory JobTask.fromJson(Map<String, dynamic> json) {
    DateTime? parseUtc(String? value) {
      if (value == null) return null;
      final dt = DateTime.parse(value);
      return dt.isUtc ? dt : DateTime.utc(
          dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second, dt.millisecond);
    }

    return JobTask(
      taskId: json['task_id'] ?? '',
      jobId: json['job_id'] ?? '',
      taskName: json['task_name'] ?? '',
      status: json['status'] ?? 'Not Started',
      startTime: parseUtc(json['start_time']),
      endTime: parseUtc(json['end_time']),
      notes: json['notes'],
      elapsedSeconds: json['elapsed_seconds'] ?? 0,
    );
  }

}
