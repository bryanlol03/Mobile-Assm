// models/part.dart

class Part {
  final String partId;
  final String name;
  final int stockQuantity;
  final num unitPrice;

  Part({
    required this.partId,
    required this.name,
    required this.stockQuantity,
    required this.unitPrice,
  });

  factory Part.fromJson(Map<String, dynamic> json) {
    return Part(
      partId: json['part_id'],
      name: json['name'] ?? 'Unknown',
      stockQuantity: json['stock_quantity'] ?? 0,
      unitPrice: (json['unit_price'] ?? 0) as num,
    );
  }
}
