// models/job_details.dart
import 'part.dart';
import 'job_part.dart';
import 'service_entry.dart';

class JobDetails {
  final String jobId;
  final String description;
  final String status;
  final String priority;

  // vehicle
  final String? vehicleModel;
  final int? vehicleYear;
  final String? vehicleNo;
  final String? serviceHistory;

  // customer
  final String? customerId;
  final String? customerName;
  final String? customerPhone;
  final String? customerEmail;

  // parts
  final List<JobPart> parts;
  final List<ServiceEntry> history;

  final String? signatureUrl;
  final DateTime? signedAt;

  const JobDetails({
    required this.jobId,
    required this.description,
    required this.status,
    required this.priority,
    this.vehicleModel,
    this.vehicleYear,
    this.vehicleNo,
    this.serviceHistory,
    this.customerId,
    this.customerName,
    this.customerPhone,
    this.customerEmail,
    this.parts = const [],
    this.history = const [],
    this.signatureUrl,
    this.signedAt,

  });

  factory JobDetails.fromJson(Map<String, dynamic> json) {
    final vehicles = json['vehicles'] as Map<String, dynamic>?;
    final customer = vehicles?['customers'] as Map<String, dynamic>?;

    final partsArray = (json['job_parts'] as List<dynamic>? ?? [])
        .whereType<Map<String, dynamic>>()
        .map((row) => JobPart.fromJson(row))
        .toList();

    final historyArray = (json['service_entries'] as List<dynamic>? ?? [])
        .whereType<Map<String, dynamic>>()
        .map(ServiceEntry.fromJson)
        .toList();

    final signoffs = (json['job_signoffs'] as List<dynamic>? ?? [])
        .whereType<Map<String, dynamic>>()
        .toList();
    String? sigUrl;
    DateTime? signed;
    if (signoffs.isNotEmpty) {
      final s = signoffs.first;
      sigUrl = s['signature_url'] as String?;
      final ts = s['signed_at'] as String?;
      if (ts != null) signed = DateTime.tryParse(ts);
    }

    return JobDetails(
      jobId: json['job_id'] ?? '',
      description: json['description'] ?? '',
      status: json['status'] ?? '',
      priority: json['priority'] ?? '',
      vehicleModel: vehicles?['model'],
      vehicleYear: vehicles?['year'],
      vehicleNo: vehicles?['vehicle_no'],
      serviceHistory: vehicles?['service_history'],
      customerId: customer?['customer_id'] as String?,
      customerName: customer?['name'],
      customerPhone: customer?['phone'],
      customerEmail: customer?['email'],
      parts: partsArray,
      history: historyArray,
      signatureUrl: sigUrl,
      signedAt: signed,
    );
  }

  num get partsTotal => parts.fold<num>(0, (sum, p) => sum + p.lineTotal);
}
