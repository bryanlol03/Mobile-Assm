package my.edu.tarc.mobileasgm

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
